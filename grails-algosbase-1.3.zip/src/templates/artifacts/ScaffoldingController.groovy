@artifact.package@class @artifact.name@ {
    static scaffold = true
} // fine della classe
