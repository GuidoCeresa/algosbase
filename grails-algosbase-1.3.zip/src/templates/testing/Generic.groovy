@artifact.package@import static org.junit.Assert.*
import org.junit.*

class @artifact.name@ {

    @Before
    void setUp() {
        // Setup logic here
    }

    @After
    void tearDown() {
        // Tear down logic here
    }

    @Test
    void testSomething() {
        fail "Implement me"
    }
}
