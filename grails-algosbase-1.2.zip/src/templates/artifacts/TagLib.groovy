@artifact.package@class @artifact.name@ {

} // fine della tag library
