package algosbase

/**
 * Created with IntelliJ IDEA.
 * User: Gac
 * Date: 3-10-12
 * Time: 08:03
 * To change this template use File | Settings | File Templates.
 */
class Lib {
    static LibArray Array = new LibArray()
    static LibWeb Web = new LibWeb()
    static LibDate Date = new LibDate()
    static LibTesto Txt = new LibTesto()
    static LibMat Mat = new LibMat()
    static LibHtml Html = new LibHtml()
    static LibFile File = new LibFile()

} // fine della classe statica
