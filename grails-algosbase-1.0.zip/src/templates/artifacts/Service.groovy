@artifact.package@class @artifact.name@ {

    def serviceMethod() {
    } // fine del metodo

} // fine della service classe
